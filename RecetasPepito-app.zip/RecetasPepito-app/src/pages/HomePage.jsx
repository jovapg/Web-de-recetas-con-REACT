import { useState } from "react";
import Aside from "../components/Aside";
import Footer from "../components/Footer";
import Header from "../components/Header";
import Menu from "../components/menu";
import Recetas from "../components/Recetas";
import TiposRecetas from "../components/TiposRecetas";
import Navlogin from "../components/Navlogin";


export default function HomePage() {
  const [search, setSearch] = useState("");
  const [limit, setLimit] = useState(4); // Mostrar inicialmente 4 tarjetas

  return (
    <>
       <Navlogin/>
      <Header />
      <Menu search={search} setSearch={setSearch} />
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-4 d-flex">
            <div className="w-100">
              <Aside />
            </div>
          </div>

          <div className="col-md-8">
            <div className="row">
              <Recetas search={search} limit={limit}  cardsPerRow={2}/>
             
            </div>
            <div className="text-center my-4">
              <button className="btn btn-outline-primary" onClick={() => setLimit(limit + 4)}>
                Cargar más
              </button>
            </div>
          </div>
        </div>
        <TiposRecetas />
      </div>
      <Footer />
    </>
  );
}
