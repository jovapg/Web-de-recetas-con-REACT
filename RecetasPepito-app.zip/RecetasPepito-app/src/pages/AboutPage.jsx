import Header from "../components/Header";
import Menu from "../components/menu";
import Footer from "../components/Footer";

export default function About() {
  return (
    <>
      <Header />
      <Menu />

      <div className="container mt-5 mb-5">
        <h2 className="text-center mb-4">Sobre Nosotros</h2>

        <div className="card shadow p-4 bg-light">
          <p>
            ¡Bienvenido a nuestra plataforma de recetas! Nuestro objetivo es brindar a los amantes de la cocina un espacio donde puedan descubrir, compartir y disfrutar de deliciosas recetas de todo el mundo.
          </p>
          <p>
            Ya seas un chef profesional o estés dando tus primeros pasos en la cocina, aquí encontrarás ideas fáciles, prácticas y sabrosas para cada ocasión. Nos apasiona la comida, y creemos que cocinar debe ser divertido, creativo y accesible para todos.
          </p>
          <p>
            Este proyecto fue creado con amor, dedicación y mucho café ☕. Esperamos que disfrutes explorando y cocinando tanto como nosotros disfrutamos creando este espacio para vos.
          </p>
          <p className="fst-italic text-end">
            - El equipo de Recetas Creativas 🍽️
          </p>
        </div>
      </div>

      <Footer />
    </>
  );
}
