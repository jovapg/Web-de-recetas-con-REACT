import React from 'react';
import { useForm } from 'react-hook-form';

export default function Login() {
    let { register, handleSubmit} = useForm();
    let onSubmit = () => {};

  return (
   <>
    <div className="min-vh-100 d-flex justify-content-center align-items-center bg-dark bg-gradient">
      <div
        className="bg-dark bg-opacity-50 border border-light rounded-4 shadow p-4 text-white"
        style={{ backdropFilter: 'blur(10px)', maxWidth: '400px', width: '100%' }}
      >
        <h1 className="text-danger mb-2 text-center">Login</h1>
        <p className="text-secondary text-center">Bienvenido de nuevo</p>
        <form id="loginForm">
          <input
            type="email"
            className="form-control mb-3 bg-dark text-white border-0"
            placeholder="Correo electrónico"
            required
          />
          <input
            type="password"
            className="form-control mb-3 bg-dark text-white border-0"
            placeholder="Contraseña"
            required
          />
          <button type="submit" className="btn btn-danger w-100 mb-2">
            Iniciar sesión
          </button>
          <p className="text-center text-secondary small">
            ¿No tienes cuenta?{' '}
            <a href="#" className="text-warning text-decoration-none">
              Regístrate
            </a>
          </p>
        </form>
      </div>
    </div>
 </>
  );
}
