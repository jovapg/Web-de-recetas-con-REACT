import { Link, useLocation } from "react-router-dom";
import Menu from "../components/menu";
import Footer from "../components/Footer";
import Header from "../components/Header";
import Recetas from "../components/Recetas";
import TiposRecetas from "../components/TiposRecetas";
import { useEffect, useState } from "react";

export default function CategoriesPage() {
  const location = useLocation();
  const [search, setSearch] = useState("");

  useEffect(() => {
    const hash = location.hash;
    if (hash) {
      const id = hash.replace("#", "");
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [location]);

  const categorias = [
    "Postres",
    "Comidas Rápidas",
    "Bebidas",
    "Entradas",
    "Platos Principales",
  ];

  return (
    <>
      <Header />
      <Menu search={search} setSearch={setSearch} />

      <div className="container mt-5 text-center">
        <h3 className="mt-4"> Categorías</h3>

        <div className="d-flex flex-wrap gap-3 mb-4 text-center justify-content-center">
          {categorias.map((cat) => (
            <Link
              key={cat}
              to="/Categories"
              state={{ categoria: cat }}
              className="btn btn-outline-secondary text-uppercase fw-bold"
              style={{ transition: "0.3s" }}
              onMouseEnter={(e) =>
                e.target.classList.add("bg-warning", "text-dark")
              }
              onMouseLeave={(e) =>
                e.target.classList.remove("bg-warning", "text-dark")
              }
            >
              {cat}
            </Link>
          ))}
        </div>

        <hr />

        <div className="row">
          <Recetas search={search} />
        </div>
      </div>

      <TiposRecetas />
      <Footer />
    </>
  );
}
