

export default function NotFoundPage() {
  return (
    <div>
      not fpund page
    </div>
  )
}
