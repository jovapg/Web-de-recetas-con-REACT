import Menu from "../components/menu";
import Footer from "../components/Footer";
import Header from "../components/Header";

export default function ContactPage() {
  return (
    <>
      <Header />
      <Menu />

      <div
        className="py-5"
        style={{
          backgroundImage: `url("https://images.adsttc.com/media/images/6019/522f/f91c/8198/f400/0079/newsletter/shutterstock_1508299232_recortada.jpg?1612272115")`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          minHeight: "100vh",
        }}
      >
        <div className="container bg-white p-5 rounded shadow" style={{ maxWidth: "600px", opacity: 0.95 }}>
          <h2 className="mb-4 text-center">Contáctanos</h2>
          <form>
            <div className="mb-3">
              <label className="form-label">Nombre</label>
              <input type="text" className="form-control" placeholder="Tu nombre" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Correo Electrónico</label>
              <input type="email" className="form-control" placeholder="nombre@ejemplo.com" required />
            </div>
            <div className="mb-3">
              <label className="form-label">Mensaje</label>
              <textarea className="form-control" rows="4" placeholder="Escribe tu mensaje..." required></textarea>
            </div>
            <button type="submit" className="btn btn-primary w-100">Enviar</button>
          </form>
        </div>
      </div>

      <Footer />
    </>
  );
}
