import { useParams, Link } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import Menu from "../components/menu";
import Footer from "../components/Footer";
import Header from "../components/Header";
import Aside from "../components/Aside";

export default function DetailsRecetas() {
  let { receta_id } = useParams(); // Capturar ID de la receta desde la URL
  console.log("Receta ID recibido:", receta_id);

  let [receta, setReceta] = useState(null);
  let [cargando, setCargando] = useState(true);

  useEffect(() => {
    let fetchReceta = async () => {
      try {
        let response = await axios.get("http://localhost:3001/api/recetas"); // Obtener todas las recetas
        console.log("Recetas obtenidas de la API:", response.data);

        let recetaEncontrada = response.data.find(r => String(r.receta_id) === String(receta_id));

        console.log("Receta encontrada:", recetaEncontrada);
        setReceta(recetaEncontrada || null);
      } catch (error) {
        console.error("Error al obtener las recetas:", error);
        setReceta(null);
      } finally {
        setCargando(false);
      }
    };

    fetchReceta();
  }, [receta_id]);

  if (cargando) {
    return (
      <>
        <Header />
        <Menu />
        <div className="container mt-5">
          <h2 className="text-info">Cargando receta...</h2>
        </div>
      </>
    );
  }

  if (!receta) {
    return (
      <>
        <Header />
        <Menu />
        <div className="container mt-5">
          <h2 className="text-danger">Receta no encontrada</h2>
          <Link to="/" className="btn btn-secondary mt-4 rounded-pill">← Volver al Inicio</Link>
          <Link to="/Categories" className="btn btn-secondary mt-4 rounded-pill">← Volver a Categorías</Link>
        </div>
      </>
    );
  }

  return (
    <>
      <Header />
      <Menu />
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-4">
            <Aside />
          </div>
          <div className="col-md-8">
            <h1 className="mb-4">{receta.receta_nombre}</h1>
            <img
              src={receta.imagen}
              alt={receta.receta_nombre}
              className="img-fluid mb-4"
              style={{ maxHeight: "400px", objectFit: "cover", width: "100%" }}
            />
            <p><strong>Categoria:</strong> {receta.categoria}</p>
            <p><strong>Autor:</strong> {receta.autor}</p>
            <p><strong>Ingredientes:</strong>{receta.ingredientes}</p>
           
            <Link to="/" className="btn btn-secondary mt-4 rounded-pill">← Volver al Inicio</Link>
            <Link to="/Categories" className="btn btn-secondary mt-4 rounded-pill">← Volver a Categorías</Link>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}