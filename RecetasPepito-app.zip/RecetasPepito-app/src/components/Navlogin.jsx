

export default function Navlogin() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-4">
      <a className="navbar-brand" href="#"></a>

      <div className="collapse navbar-collapse">
        <ul className="navbar-nav me-auto">


        </ul>
        <button className="btn btn-outline-light">
          🔐 Login
        </button>
      </div>
    </nav>
  );
}
