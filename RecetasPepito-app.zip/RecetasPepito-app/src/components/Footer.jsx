
export default function Footer() {
  return (
    <div className="mt-5 p-4 bg-dark text-white text-center">
        <p>@Todos los derechos reservados - Recetas App Jovany y Angeline - 2025</p>
    </div>
  )
}
