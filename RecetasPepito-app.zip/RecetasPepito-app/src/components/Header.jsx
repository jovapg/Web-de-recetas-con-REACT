import "./../assets/estilos.css";
export default function Header() {
  return (
    <div className="header-banner text-white text-center d-flex flex-column justify-content-center align-items-center">

        <h1>
            <img className="logo" src={"https://png.pngtree.com/png-clipart/20221019/original/pngtree-master-chef-logo-illustration-png-image_8703909.png"} alt="" />
            Recetario Don Pepito</h1>
        <p>Las Mejores en recetas y postres</p> 
    </div>
  )
}
