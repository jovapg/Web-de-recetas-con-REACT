export default function Card({recetas}) {
  
  return (
    <>
      <div className="my-3">
        <h2>{recetas.titulo}</h2>
          <h5>{recetas.fecha}</h5>
          <div className="fakeimg">
            <img src={recetas.imagen} width="100%" />
          </div>
          <p>{recetas.descripcion}</p>
          <button className="btn btn-primary">Ver Receta</button>
      </div>
    </>
  )
}
