import { Link } from "react-router-dom";

export default function Aside() {
  const categorias = ["MAS IDEAS DE POSTRES", "MAS IDEAS DE SOPAS", "Ensaladas", "Arroces", "Pastas"];

  return (
    <div>
      <h2 className="fw-bold">About Me</h2>
      <h5 className="fs-5">Photo of me:</h5>
      <div className="mb-3">
        <img
          className="img-fluid rounded shadow"
          src="https://img.freepik.com/premium-photo/chef-giving-thumbs-up-isolated-white-background_1000823-51643.jpg"
          alt="Chef"
        />
      </div>
      <p className="fs-5">
        Soy chef especializado en alta cocina, graduado en la Universidad Harvard Medellín.
        Me apasiona la cocina como jugar fútbol.
      </p>
      <h3 className="mt-4 fw-bold">Algunas Categorías</h3>
      <p className="fs-5">Categorías de nuestras recetas:</p>
      <ul className="nav nav-pills flex-column">
        {categorias.map((cat) => (
          <li key={cat} className="nav-item">
            <Link
              className="nav-link"
              to={`/Categories#${cat.toLowerCase()}`}

            >
              {cat}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
