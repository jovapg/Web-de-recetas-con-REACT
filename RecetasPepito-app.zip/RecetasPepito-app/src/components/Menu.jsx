import { Link, useLocation } from "react-router-dom";

export default function Menu({ search, setSearch }) {
  const location = useLocation(); // para saber en qué ruta estás

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="navbar navbar-expand-sm bg-dark navbar-dark sticky-top shadow">
      <div className="container-fluid">
        <ul className="navbar-nav justify-content-between">
          <li className="nav-item">
            <Link className={`nav-link ${isActive("/") ? "text-decoration-underline" : ""}`} to="/">HOME</Link>
          </li>
          <li className="nav-item">
            <Link className={`nav-link ${isActive("/Categories") ? "text-decoration-underline" : ""}`} to="/Categories">CATEGORIES</Link>
          </li>
          <li className="nav-item">
            <Link className={`nav-link ${isActive("/About") ? "text-decoration-underline" : ""}`} to="/About">ABOUT</Link>
          </li>
          <li className="nav-item">
            <Link className={`nav-link ${isActive("/Contact") ? "text-decoration-underline" : ""}`} to="/Contact">CONTACT</Link>
          </li>
        </ul>
        <div className="input-group has-validation align-self-end w-25">
          <span className="input-group-text" id="inputGroupPrepend">🔎</span>
          <input
            type="text"
            className="form-control bg-secondary text-white"
            placeholder="Buscar receta"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>
    </nav>
  );
}
