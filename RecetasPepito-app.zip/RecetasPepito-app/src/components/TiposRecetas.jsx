

export default function TiposRecetas() {
    return (




        <div className="container mt-5">

            {/* POSTRES*/}
            <div id="postres" className="recetas-faciles px-3 py-5">
                <h2 className="fw-bold text-center mb-4" >
                     MAS IDEAS DE POSTRES
                </h2>
                <p className="text-muted text-center mb-4">
                    Si eres amante de los <strong>postres caseros</strong> y buscas opciones deliciosas, fáciles y rápidas de preparar,
                    aquí encontrarás una variedad de <strong>recetas dulces</strong> ideales para cualquier ocasión. Desde clásicos tradicionales
                    hasta creaciones modernas, descubre cómo disfrutar de postres irresistibles sin complicaciones en tu propia cocina.
                </p>


                <div className="row g-3">
                    <div className="col-md-6">
                        <div className="position-relative">
                            <img
                                src="https://www.divinacocina.es/wp-content/uploads/2024/12/trifle-de-navidad-2-585x585.jpg"
                                alt="Espaguetis al pesto"
                                className="img-fluid w-100 rounded"
                                style={{ height: 800 }}
                            />
                            <div className="position-absolute bottom-0 start-0 p-3 text-white"
                                style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                <small className="text-uppercase">Recetas de pasta</small><br />
                                <strong className="fs-5">Trifle de Navidad, receta de aprovechamiento</strong>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-6">
                        <div className="row g-3">
                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/2025/03/natillas-de-mandarina-y-jengibre-cc-585x585.jpg"
                                        alt="Brócoli con patatas"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 400 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                        <strong>BROCÓLI A LA CREMA CON PATATAS</strong>
                                    </div>
                                </div>
                            </div>

                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/2025/03/panna-cotta-de-yogur-cc-585x585.jpg"
                                        alt="Risotto de tomate"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 380 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                        <strong>Panna Cotta de yogur con salsa de naranja</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                        {/* SOPAS*/}
                        <div id="sopas" className="recetas-faciles px-3 py-5">
                <h2 className="fw-bold text-center mb-4" >
                    MAS IDEAS DE SOPAS
                </h2>
                <p className="text-muted text-center mb-4">
  Si te encantan las <strong>sopas caseras</strong> y reconfortantes, estás en el lugar indicado. Aquí te presentamos una variedad de
  <strong>recetas de sopas</strong> fáciles y rápidas de preparar, ideales para cualquier momento del día. Disfruta de sabores tradicionales y nuevas combinaciones
  que llenarán tu mesa de calidez y sabor, sin complicarte en la cocina.
</p>


                <div className="row g-3">
                    <div className="col-md-6">
                        <div className="position-relative">
                            <img
                                src="https://www.divinacocina.es/wp-content/uploads/2024/01/sopas-mallorquinas-v-585x779.jpg"
                                alt="Espaguetis al pesto"
                                className="img-fluid w-100 rounded"
                                style={{ height: 800 }}
                            />
                            <div className="position-absolute bottom-0 start-0 p-3 text-white"
                                style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                <small className="text-uppercase">Recetas de SOPAS</small><br />
                                <strong className="fs-5">Sopas mallorquinas de pan y verduras</strong>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-6">
                        <div className="row g-3">
                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/sopas-de-caldo-puchero-1.jpg"
                                        alt="Brócoli con patatas"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 400 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                        <strong>Sopas de caldo de puchero con huevo</strong>
                                    </div>
                                </div>
                            </div>

                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/sopas-serranas-de-gato.jpg"
                                        alt="Risotto de tomate"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 380 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                        <strong>Sopas serranas
                                        </strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {/* Tipos de recetas que encontrarás */}
            <div className="recetas-faciles px-3 py-5">
                <h2 className="fw-bold text-center mb-4" >
                    ¿Qué tipo de recetas de cocina fáciles encontrarás?
                </h2>
                <p className="text-muted text-center mb-4">
                    Si eres de las personas que buscan <strong>recetas de cocina fáciles</strong> y rápidas de preparar en la cocina,
                    te presentaremos una variedad de recetas de cocina sencillas que podrás preparar sin complicaciones. Encontrarás recetas
                    para cualquier gusto y ocasión que te permitirán disfrutar de <strong>comidas caseras</strong> deliciosas en poco tiempo.
                </p>

                <div className="row g-3">
                    <div className="col-md-6">
                        <div className="position-relative">
                            <img
                                src="https://www.divinacocina.es/wp-content/uploads/2014/03/espaguetis-al-pesto-en-plato-v2-768x960.jpg"
                                alt="Espaguetis al pesto"
                                className="img-fluid w-100 rounded"
                                style={{ height: 800 }}
                            />
                            <div className="position-absolute bottom-0 start-0 p-3 text-white"
                                style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                <small className="text-uppercase">Recetas de pasta</small><br />
                                <strong className="fs-5">CÓMO HACER ESPAGUETIS AL PESTO</strong>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-6">
                        <div className="row g-3">
                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/2021/02/brocoli-a-la-crema-con-patatas-cc-768x768.jpg"
                                        alt="Brócoli con patatas"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 400 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                        <strong>BROCÓLI A LA CREMA CON PATATAS</strong>
                                    </div>
                                </div>
                            </div>

                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/2025/01/risotto-de-tomate-con-mozzarella-1-768x768.jpg"
                                        alt="Risotto de tomate"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 380 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0, 0, 0, 0.5)", width: "100%" }}>
                                        <strong>RISOTTO DE TOMATE CON MOZZARELLA</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Recetas que están de moda */}
            <div className="recetas-moda px-3 py-5">
                <h2 className="fw-bold text-center mb-4" >
                    Las recetas que están de moda en Divina Cocina
                </h2>
                <p className="text-muted text-center mb-4">
                    En Divina Cocina te traemos las <strong>recetas más populares y en tendencia</strong> para que sorprendas en
                    cada ocasión. Desde platos tradicionales reinventados hasta propuestas creativas y fáciles de preparar,
                    nuestras recetas de moda te permitirán explorar nuevos sabores y técnicas en la cocina, siempre con ese toque
                    especial que hace que tus platos sean irresistibles. ¡Descubre qué está marcando tendencia y anímate a probar algo nuevo!
                </p>

                <div className="row g-3">
                    <div className="col-md-6">
                        <div className="position-relative">
                            <img
                                src="https://www.divinacocina.es/wp-content/uploads/2019/06/BERENJENAS-RELLENAS-DIVINA-COCINA-FOTO-585x585.jpg"
                                alt="Berenjenas rellenas"
                                className="img-fluid w-100 rounded"
                            />
                            <div className="position-absolute bottom-0 start-0 p-3 text-white"
                                style={{ background: "rgba(0,0,0,0.6)", width: "100%" }}>
                                <strong className="fs-5">Cómo hacer berenjenas rellenas de carne al horno fáciles y deliciosas</strong>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-6">
                        <div className="row g-3">
                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/2014/10/panna-cotta-con-coulis-frutos-rojos-v-585x731.jpg"
                                        alt="Panna Cotta"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 310 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0,0,0,0.6)", width: "100%" }}>
                                        <strong>Cómo hacer Panna Cotta italiana, la receta original</strong>
                                    </div>
                                </div>
                            </div>

                            <div className="col-12">
                                <div className="position-relative">
                                    <img
                                        src="https://www.divinacocina.es/wp-content/uploads/2020/05/galletas-de-limon-cesta-585x585.jpg"
                                        alt="Galletas de limón"
                                        className="img-fluid w-100 rounded"
                                        style={{ height: 310 }}
                                    />
                                    <div className="position-absolute bottom-0 start-0 p-2 text-white"
                                        style={{ background: "rgba(0,0,0,0.6)", width: "100%" }}>
                                        <strong>Cómo hacer galletas de limón caseras</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
