
import { Link } from "react-router-dom";


export default function Receta({ recetas }) {
  const {
    receta_id,
    categoria,
    receta_nombre,
    autor,
    ingredientes,
    imagen,
  } = recetas;

  return (
    <div className="card h-100 shadow-sm">
      <Link to={`/Categories/${receta_id}`}>
        <img
          src={imagen}
          className="card-img-top"
          alt={receta_nombre}
          style={{ height: "250px", objectFit: "cover" }}
        />
      </Link>

      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{receta_nombre}</h5>
        <h6 className="card-subtitle mb-2 text-muted">Autor: {autor}</h6>
        <p className="card-text">{categoria}</p>
        <p className="card-text">
          <strong>Ingredientes:</strong> {ingredientes}
        </p>

        <div className="mt-auto">
          <Link
            to={`/Categories/${receta_id}`}
            className="btn btn-primary w-100 rounded-pill"
          >
            
            Ver receta completa
          </Link>
        </div>

      </div>
    </div>

  );
}