import Receta from "./Receta";
import axios from "axios";
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

export default function Recetas({ search = "", limit = null, cardsPerRow = 3 }) {
  const [recetasApi, setRecetasApi] = useState([]);
  const location = useLocation();
  const categoriaSeleccionada = location.state?.categoria || null;

  async function getRecetas() {
    try {
      const respuesta = await axios.get("http://localhost:3001/api/recetas");
      setRecetasApi(respuesta.data);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    getRecetas();
  }, []);

  const filtro = search.toLowerCase();

  const recetasFiltradas = recetasApi.filter((r) => {
    const coincideCategoria = categoriaSeleccionada ? r.categoria === categoriaSeleccionada : true;
    const textoBuscado = `${r.receta_nombre} ${r.autor} ${r.ingredientes}`.toLowerCase();
    const coincideBusqueda = filtro ? textoBuscado.includes(filtro) : true;
    return coincideCategoria && coincideBusqueda;
  });

  const recetasMostradas = limit ? recetasFiltradas.slice(0, limit) : recetasFiltradas;

  // Determinar clases según cantidad de tarjetas por fila
  const colClass =
    cardsPerRow === 2
      ? "col-md-6"
      : cardsPerRow === 3
      ? "col-md-4"
      : "col-md-4"; // por defecto 3 por fila

  return (
    <>
      {recetasMostradas.length > 0 ? (
        recetasMostradas.map((data) => (
          <div className={`${colClass} mb-4`} key={data.receta_id}>
            <Receta recetas={data} />
          </div>
        ))
      ) : (
        <p>No se encontraron recetas.</p>
      )}
    </>
  );
}
