import { Routes, Route, Navigate } from "react-router-dom";
import HomePage from "./pages/HomePage";
import CategoriesPage from "./pages/CategoriesPage";
import ConctactPage from "./pages/ConctactPage";
import AboutPage from "./pages/aboutPage";
import NotFoundPage from "./pages/NotFoundPage";
import DetailsRecetas from "./pages/DetailsRecetas";
import ScrollToTopButton from "./components/ScrollToTopButton";
import Login from "./pages/login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Navlogin from "./components/Navlogin";
import { useState } from "react";

function App() {
  let [isAutenticated, setIsAuthenticated] = useState(false);
  let handleLogin = () => {
    setIsAuthenticated(true); //token de autorización 
  };
  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/Categories" element={<CategoriesPage />} />
        {/* <Route path="/Categories/:id" element={<DetailsRecetas />} /> */}
        <Route path="/Categories/:receta_id" element={<DetailsRecetas />} />
        <Route path="/About" element={<AboutPage />} />
        <Route path="/Contact" element={<ConctactPage />} />
        <Route path="*" element={<NotFoundPage />} />

        <Route path="/Login" element={ isAutenticated ? <Navigate to="/Dashboard" /> :  <Login />} />
        <Route path="/Register" element={ isAutenticated ? <Navigate to="/Dashboard" /> :  <Register />} />
        <Route path="/Dashboard" element={  isAutenticated ?  <Dashboard/> :  <Navigate to="/Login" /> } />

      </Routes>
      <ScrollToTopButton />
    </>
  );
}

export default App;
